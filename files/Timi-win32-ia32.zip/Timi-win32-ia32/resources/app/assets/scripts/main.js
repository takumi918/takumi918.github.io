const electron = require("electron");
const mainWindow = electron.remote.getCurrentWindow();
const ipcRenderer = electron.ipcRenderer;

mainWindow.on("move", () => {
	document.getElementById("corner").style.backgroundColor = "rgba(244, 66, 66, 0.125)";
	var pos = mainWindow.getPosition();
	//0.5秒間に亘り座標の変化がない場合
	setTimeout(() => {
		if(mainWindow.getPosition() != pos) {
			document.getElementById("corner").style.backgroundColor = "rgba(0, 0, 0, 0)";
		}
	}, 500);
});

enchant();

var defaultTheme = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4goBCCIKLCCRawAAAB1pVFh0Q29tbWVudAAAAAAAQ3JlYXRlZCB3aXRoIEdJTVBkLmUHAAAPQElEQVR42u2dXYxc5XnHf2e9u3BpPgRLjXMxYNkGItkSpBCwkc95Zm0LJ6UQbYVlC7vYEkS+SFuQasE6BJu4CIQqQSEKRiZAHMWCFFIj7J1nhuLFpSqWHLV8CjwXNYHFIcW9iBRmbE4v5lDRYs85uzOz8/X/SXNh7eNz3vd5/s95P8553xeEEEIIIYQQQgghhBBCCCHEtDCzW8xsST2bShTtrETRzpTrLDGzW+TR1jAgF0yPfD4fJMIcTDFdBlyXYvN58qvHdcm16iXJIMDo6GigCCkBWkqhUIjN7CAwlmI6BVzYhFteAHycYjNmZq9OTEzEipASYDbYDyxNsfkYuLgJ97o4QwIsTcoklAAN9903m9mtKWavAqtSbI4CC5tQpEVAOcVmFXAwpV63mtlmRVgJkMbvgdvqGbj7IeCKlOu8n4i3URYHQfB+is0VSZnqcVtSN6EEqCvuX6UNOhM+M7NcnescA85pQpHmFgqFY3UG5TngRIbrLEvqJvo1AczsbDO7M4PpS2a2PsXmRWC0wSKdlfxmTBzHo8ALKfVeD7yUwT93mtnZSoDefbr/EXjQzEZSTPcA61JsDgNXptiM15suHS4Wtw4Xi1vP9PeVK1cOAttS7nEl8EaKzbqkTtRpSUaABxMf9Q2D9B/3AtuBzXUSZY+Z/TzlOhPA6pSE29FIQQ8cOHAyKWs9RoBCis2ou69MaUm2J74RPd4NGjCz2MyCFLuSmY31QH3HzKyYwS42s74bE/ZchatheGXKU/kL4Cng7gzdoL/oAZeMAb9IEf/dwO7EN2ekEkVX6RHa2eJfVA3D1LehZjbPzPTW9CtP/3w+Py/NrhJFcSWKFspjnZ0EP62G4SMZgn7QzNZJ/LYu+bQjTfyPVKLop+oCdT63A1uqYZg203MP8CM9MvhR4ot64r8Q2JL4VnRBK7ClGoaHstimDYZ7/Omfqe6VKDpUiaItUlZnBG00YxKcqIbhCnmsMSpRtKISRSeaGRt1gRpjr5ltyGD3HWCfJNww+4A1GcS/AdirBGg9lwK7zeyCekZDpdIkMFkNw6XS8Iyf/kuAyeFi8bUU8V8A7E5iI2ahG7TezH4nT3RMPI5n+HZKNNnpvzazx+WJtsfhMTN7UZ5oj/OrZhbKE23z/wozq3ZzHTpuDLB69eoBM3s4o/k3gaKZnSc5zrr4zwNKpC8M+tL+4U781qjjCvTyyy9/Aawws11ptu7+LvA9si0IEc3lBPA9d38vg/h3ASvSvjUS/9dpU2a2TZ7o+jhuM7MpdYGmz3xgq5ltlIy6VvwbgK1JLDuSoMMdeA7wX4C5e1GS6irxh0ARONfdP1MLMPN+5jcAN7PFklV3kM/nFwPFIAjma3x2BlavXp05+czsGjN7QF7rmqf/A2Z29TTsB/rRSQ+b2RHJpe+T5cg0pr17awyQTI+tAea7e1Vy6CvhDwHHgH3uvqlvB8HJVOdW4E+AE+6upYq9LfwAmAt8BOx09/v6ehCcOOD71GZ7LpZEepsgCOYlsb6j3eLviBbgK0+GCHDg2+7+uqTSk0//q4HXgcjdS51Qpo4ZfSfz/JcBN0oqPcufB0FwWaeIXwh1yWah2RultlTuUnf/VC4XGTRzPvABMObuE62815xWV6ZcLh/N5XJTwKFcLlcul8v/rhCLOuJfn4wT7nD353tmEJysG30LeN3dv6tQi9No5EXgGmoHfhzviS7QaSr5OLAJ+GbyPb+Q8BcCbwJPuPv3Z/Pec2a7suVy+aVcLncI+LdcLvdmuVx+RxLoa/HfTO18M3P3f5jt+7dlGjSZBjuflJNNRF/wAnC+u78iVwjR7VSiaJG8IFpBtQVbswdNFv+X51U9Adw+XCxqEbRoXPhhOAD8hNqxVt8aKpXeaNa1mzoGGC4WDw8XiwHwOXBKOwqLJoh/C3AK+HyoVAqaKf6mtwD/rzUYAZ4HLge+M1wsTiqcYhrCv47axrxvATcNlUqftOI+LX8PUImiFUlFJoeLxVUKrcgg/v3UDitfM1Qq9cbsUCWKtEuzyJoAS+QFIYQQHYyZnS0viG7WYEPfAuVyuR/kcrlDuVyOXC43WS6XtaBdzIboB3K53LZcLvfPwH+Xy+V/mem1giYUZgTYTu0Lz6eAe9z9twqTaDb5fH5eHMfbgY3AriAIxguFQkMb7wZNzMoAuDtJhskkEQ4qbKIJ2loO7KA2NXqPu9/f6QVeZ2ZHFTrRJD0dNbN13VjwQOET0pAQQgghRNf3yTab2U3yhOgwXd5kZpun+/8GZ3CvCvADM3seeAnY4+57FALRBtGvBdYCN1Cben9yutcIGizAemAdMAq8kiTDLoVGtFD0m4BbgBCYAJ5192c6oWBjSasgRCt19pyZjckTQgghhBBCiJaRz+f1PYboKkZHRzNpNrOwzewgsB941d0PycWi0zCza4HlwCp3v75pCWBmg8AYsBRYBVwBfAa8CBwGJtz9fYVAzKLYFwB54Cpq58rNpbbF+n7gCLDX3U82rQU4TQFy1F6AXQmMuPsahUXMYgLsA6aAw0EQTBQKhbK8IoQQQgghhBBCCCFOT+o0qJndQm0/lingY+Ao8L67H5P7RKeQz+fnx3G8AMgBFyW/SXf/Rb3/l2VF2DvAecCFwLep7cq1yMzOSf4+7u47FAIx25jZOHAfQBzHJxKtvgt8CLyd/LvlhRhUKEQ7WLlypbQnhBBCCCGEEEIIITKQ+iKsEkU7qZ38fjrOGi4Wt8qNol00qs8BuVAIIYQQQgghhBBCCCHqok9SRbtoxqf4gxlusgS4DrgAuBhYBCymthMXp06d2kbtdHghZpu/NbMvtfcZtcUw71FbEPMJ8Jq7/6beBaazJPLj5FcOguD9QqGgJZGik1qD+cAC4BJqyyFHyLAkUgghhBBCCCGEEEL0AzM+ICOfz+fiONYBGaItfPWADGonFM3ogIzBjDf72hFJyU5cLwBvAAWFRMwyf0XthKI/BX6c7FTYuiOSzOzV5OIHdUie6NBW4VrgemqH5C1v2oWzHjkpRKego32FEEIIIYQQrR6Bj5nZc/KEaLHOnjezsWZdb7DBwqwH1lGbjy0B+vZatJqXgdvN7JfABPCsuz8z04sFMxD9rcBt1BbJvATscfc9iotoQ2uwFlgL3ABMAk+6+89a3QIMA3/f1BcNQsyA5MG7J0mGm6idZSeEEEIIIdo7SNH3GKL/NGRm68zsqMInmqSno2a2rhXXHmxyQe8GdlCbktqo0IkmsRHYYWbPAOPA/e4eN+PCDTcv+Xx+JI7j7cAmYHcQBOOFQuG3iploQUswL3nAbgB2AePuPtW2BDCzO4EHgXuB7e7+hcIkZiERBpKW4F7gLnd/qF0FOVvhEG1OBmlQCCFEJ1MNwyXygshCJYqWzta9BmZB+CuqYfgH4O8UWpGRnZUo+kMlila0+kZBC4V/IfAr4HJgzVCp9JriKqbRCiwD/gl4C7h5uFic6prCV8PwkWoYxtUw3KJQigYTYUsliuJKFD3S8V2gahheVQ3DGDgLmDNUKj2qEIpGGC4WHwXmAGcliXBlZz/9o2ihwiZa1BoskheE6AXM7DwzmyNP9L0O5phZ25YyDrSp0iuAT4EbJYG+50bgUzML23HzoA3ifwzYDFzh7u8p/sLMFgH/Aexy9zt6MgHM7AJq+7e/7u5/prCL02jk18A1wOXufrxnukBmtoHayd1/I/GLM+Hu3wX+Gvgk0Uz3twBmNgrsBS51908VZpFBM+cDHwBj7j4hjwjRD+Tz+cVm9oA80bNP9gfMbHEnlWmgg5wTxnH8NvCPkkrP8gLwtplFSoCvD5KLQRDMd/d/lU56dpD7OvANwM1soxKgJv5twOPAuXEcazeJ3udD4FzgsST2bSVos/h3AWuA+e5elTb6ajwwBBwD9rn7pn50wMNmdkRS6PtEOGJmD/djxQemYXu1Zoe6KrYPmNk1We1Xr17dtq540OGODIIgmBfH8bEgCC4rFArvSF5dkQCLgbeTAe+HzdrGsCcHwSnMjeP4GBBJ/N2Du78DGPCfwNxOLmvHJkAySPoI2OjuJcmq65KgCPwl8FESSyXANDkG7HT3pySnrk2C3cDOJJZimjMDuzLa3qyVZW2J0Rwzuzmj7a5OnfEb6EDHDgCvZJkbNrOFwHOd3s/sUeYCzyWLWdJagk3AK+2c7enVp1A1WV4p2uP/0Mz0ArNNzn8xWV4p2huHx5OVXGIWnb7ezI7LEx0Tj9+Z2fpuLPtAFzr7fOBp4Io020oU7a9EkXalniHVMFxaDcP9GUwvB55OYqMEaDEfUHs3cDxF/NcBy4aLxd9IyjNjqFQ6AiyrhuGylEHucWoH2X2gBGg9YxnfDeyj9qWpaIw11HZpJiUJngLG5K4OINlR+FDGLlXfHuadte7VMDzUqzt9Bz0o/gHgFDAyXCx+Uif4y4Hd7n5Jnw9gjyZdyoN1EmAE+Jjajt89dRJoL76Y+AnwaD3xJ+wAfqj2kh8mvqg3FpgCHk18Kzr46b+wEkWpn97m8/l5ZhbLY//bCsTJIdRpXaG4GoY9tUV5T7UAw8Xie8C30uySk+3vSRHFJjN7rgfE/byZpX1WMp7WCiRcNVQqvasE6OwkeCNFEANJn/f+lEvdQm1Hu27nl8DaFJv7gQ1pq/SGSqXDvaaXfvw4aRzI8qVp6O576yTSAjPb1wFP+H1mtuBMf0/qUPd7qWTF1q7EN31FPybAvUEQjKeIai2QtidlHphKuc74ypUrBxsQ96CZ3ZNiNgWMpthMJHVKezDcqwTo7cHe2cBdhUIh7cjNtcCzaf1hIK1LcN+BAwdO1hm076xE0c46T+aTwPaUexwG0g6OezatG+TuU8BdiY/6hsF+qqy7/xF4KIPpDe6e9hb5xiAItjdYpM+bUK0J4Mcp9X7GzJ7O4J+H6DO0QOHrrcRNwGQG07mFQqF8xv5RPj8fONGEIn1mZvPriLYMnJPhOpNJ3YQSoC7nAU+mJMm11E67OSNxHC8AmrGTxbvAghSbN5My1ePJpG6iX7tAGbtJT2QwWw6kfSacS8TbKO8BlwD1dsbYD1wPHKpTr58pumoBmsUqIG2R90XUNoJtlA+Ta9XjSFImoQRoLaOjo4G7X0/6S7KLgGasWvsEGEmx2evuy/P5fKAIqQvUUiYmJuKkS3EybdCZYQxwVoZbvgb8PqXbdhKgUCjo+yYhhBBCCCGEEEIIIYQQQoiE/wEro/fupsrVIAAAAABJRU5ErkJggg==";
var colourTheme = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAAVKElEQVR42u2daXBU15XHm4QkpmbKjqHsODZe4sokzownS+VLPgwVZmoWj0nFSRzXkCpnBn+hZiZUQQXkEaacgKl4QHhAkLIMFAgwBoGEQNgsAgRiMUYYSSwWCATaQAiE9gVJoOXO+T+6VaLpfu929+vu9/r9f1WnkHHTeu/e/7nLufee6/MRQgghhBBCCCGEEEIIIYQQS5RST4n9ROy1zZs359TV1a2Wn/PETog1qGCGd9+zB2nw/5tcfAe+C9/p/+4nWdIk2UIfX19fD0G+KfahWLlY32gFb9myRRUVFSlTwjvACB9//LHxXUH0+X/nBrE0/7OMZ82QeAn+SbHXxdCiX3j//ffV6dOnLYULs8MBrL4Hz4JnwrP5n/F19hQkFsGPEfux2B/FTkGqGq3yfaD1X7duXcwOgO84fvy46WfwLCGcZNj/7H8Q+xFrlViJ/qtiU0RIxaWlpW1mgrt48aJasmSJivUzOg6A78B3xfqZU6dO3SooKDggP/4j3pU1TiD6R8X+QyxfrBtCQWvrH06E5fbt22r69OkJcYB33nnHUtxWzwKChm14121iv0UZUAneE/6XxX4pdiScuPGnlTCvXr0amzA1HMDqO/AMeBYdhw3zTofFXkGZUBkpTk5OztM7d+5cK5Vda9VaWo27dcbmiXAAnbmGTq+GMtkkrFq16ptUSmpGcf5PrHPmzJmqpaUlZsHoCA8TU6uexKrltgql4hmsPqPj0CgTlI3QKvYnRpFSQ/hfF8sQ6x0tSivh6gyDMPSwigQlAjyD2VBMd0iHMgmKJKHMFqMMqST3Cf8vxeaKtYcSBFo6K0HotJpuIJJJfZgyQRmmi42jspwu/Mq5E1T7sfkhtx2Yt3YhhWMZx3cBOnMVnV4RZXqtY/Pikw3/PoFKc2ar/yvVW12rKmYoNXjbcrybnp6uyD105kUDQ93qeO3PVFf/BQQQfkHFOUf4z4jtGKmpaxLkuZ5jWemI0SdziJOdna1OnDhx33+npaWp8+fPJ3yIZLleIVxp+bNho0CZP0MFJk/4XxKbLdZzX02h9UcvcLfZcqFKIzQYVzIzM0fED+F3dnZqLWrZic4qcv/ADWn9pxi9QBAo+9+jLqjIxIp/otixsDXWvF+p6gzHDz0CDhAgGQ6gw9nrM1VDR57ZR1AXE6nMBLB9+/Z5UthtlrVWKTuVey66xgHQA0D8cAIn0dF3Wp2s/zedj7ahbqjQ+LX6D4mtxLK/1tgd4ocTuMAB9u3bpyZNmqQWLlyoli9f7qhnhPjhBFZgMc6/JeMD1BUVa6/4nxerCCxAIYJjtQ/HoE4mbX31DPPE0Ppfavpfy8+FqJNzYt+mcu0R/yuBnZqjIxdWG8BIYsDiWZheuUvsVSo4euGP8e9JCbtS64StCF4HdWARTVuIuqSiIxP/OHVvj75py4Nu1+po4gPr+u3tVK1NoOxRBxob/lCXX6GyNZBl+W/l5uZe16kAjDl19vWA3t5eY8l/5cqVlqueXmdwcNDyM4Hdo1pzsXs9RT3qlgo3b/kfxxoVFmd09+FgEcfMAVBRN2/eVP39/erWrVtqw4YNKisriyoPw/DwsKqpqVGFhYWqp6fHtAe2WkALgLr0rzbjHzxOpZuIf/TEyjKrggV37txRhw4dUsXFxSOVhUqdMWNGwrccuAmUTV5enqquro75u1CHqMtRjRSdIMx+noua0YWIWrO7d++qzz//3Nh309raavz94cOH1YIFC6j0EKCXxLrE2rVrjQYkFgLRuhA9NJ1glPi/gXVbszF+rJvWGhsbDQc4e/bsyN/V1tZS7SEoLy83xB9rD4k6s5gjIIfRE14X/6PhxG+yyBIVED8qF5NhEhoMDw8cOGAMf2IhgjqDE3gzK0V+fv6z8vJluhPdWOcDFL4+se5HQl3pTpCFUmjBay3/WEn4Wv3ee+/FdGicuBvUPTQALUATXnKA7EB4LMwkiXhA/Kj7UeHubK+If36oMFmsY3ziHgLJvEIMa9NTXfwviQ1FETEgKSR+k8getPFyqor/O2IdZmEzRA4imDwRl4G6RR1bhLWhke+mmvgfVkELXeFah1ijPcS5oG41e3mExh9OpW3Ne1j9JEJ2qVTYRi3L6ks5ySXRTJKhHbe3/s+J9QTG96mQapDElyCtYDvq824e+pQEezW2IjPuT4KBJqCNEKOF464cCslDzwr1ojhCZ8feHpJaQ565c+eaHXGd5Tbxj1dBB9lHg6N0iAUz5EmgAWjB4mgrDthPcJMDrNfp8jgUIhHoYL1bxP9TViuJE//gbPHnvvGYajxfy3oi8aCxp7om69x/Off8gLp4aPlA5r+ooYOS3q+/izVGbKFfMn7vrlmjlpX/t6psLVni1KHPRGOyIsIfOpipDEcozWXtkZg4dXOfIfyi+k2GI/gnxBOdP/HtaFSDOTPUwMpfq+Gr5aYviWRVTU1NxqF1pC8hpL6rUn1wdo7adHGR6rjT7OwJsTzQi2IhsylB/AMrX1WD20NfSYScPdu2bTNSlcgdvurcuXOm+WhI6pN/eYXKEvHDCcIArX3LSQ5QYPVS4XqB/fv3G3l74AgHDx5Uy5YtY84ej9N0Wyuj9xYntf5RgRR8Z86cUUePHlVDQ/fOyWA18LPPPqMKPADqXCcNownfd4IDRJ2iGYmXkH3s7bffNvaBnDx5UmVkZFAZHqCyslLt2LHDSFUTA8ntBWTo8oI8xEA0T15VVaV27949clMictHgwAT+nqQmaPCuX7+X9xgZ6CoqKoysEA0NDdF+5cCRI0e+lzQHkASq+djH8cknn0S0rQEpCzHeRwLWjz76aCQTGdIYktR2gHnz5qmNGzcaQ1/kbcXP165di+h7oDVoDtqDBpM19MGdXW3IvozUFngY/BlJ6nEkYILwA7kombs/9dmzZ4+aP3++2rRpk9Hry8V62lG/MFpDwtdxyXCAacFeiSEMtjqjW4tkpydyd3J7tHfYu3evMexpbm5WfX19lp+HlqApaAsaCzHamJYMBygJ98C6t48Tb4Kev7u7W/vzuILJ4jTh4USL/4esRuIghsVeTKQDZLLMicPITKQDNLG8icO4mSjxT2ZZE4cyOe4OsGvXrk9xfpPHGYlTgBaxfUYiRMXxbv3HlpWV9WFWPn36dGP7An4xnYEkS/TQILQITZaWlmIhaWxChj94AISmgp2BkHgCzY0WPf47qAGeHE8HWBTOG/Egunf7EhIt0FgI0Y9mUTwd4AyrgDicM/ES/1Pq3oIDIU4GGn0kHg4wlWVLXMJUrv4SL5PJ8T/hPMBG8X8NISccQrh06RLj/sRxQJPQJjSKMKnwkG0OIOd2f4bVXxxYxzZnxGADd7wWFRVxLz9JONActBe4axqahDahUWgVmrWzB0gP9QCB2L9JXndC4gI0F1gTCNMAz7LTAdazyInLWJmQ01+EOJQSO+/64qyXuA2ctB9jhwM8x7IkLuU5HoAhXmayHQ4wjeVIXErs6VIkeVHB1q1bjQUG7PfHYgOMECeB3EHQJTQKrUKzYnkxO4DEWDdhwQEJiRB3xWJDYDEMhv9HSDKAJgM6DOgSGsXf+xdoN8U9+zO3RZBkoaG9LXY4QCGLmriUQu4CJV6mxA4HqGM5EpdyxQ4HuMlyJC7lph0O0BHpb0Xe98zMzJHbXwhJEh12OEBEF/fiytPs7GwjBXZaWpqxVxs/E6JLcMMZ6Q0ytjrA4NYCNZS7M6wFA9GPzEBKSgxnQJyWV58SXfGj0RwN/hu3CIViZU25WlUb2j6oKRuwxQHMLBg8KESPF4Hw4b3oAWLwYuIhMHQOjBigo1ANa7ADmFnCh0ABL8aLsNUnkQLNoOGEfubMmTOy0huuB7CgPymTYEJiwcYRQwfDoMTL3ORCGPEyddwKQbzMGW6GI16mkNuhScqSkO3QgQMxOGWDwwa4sRvGAzEk2UB7AR0GdAmNQqu2HYjBkUhk4cIpG2ThwtEzGCFOIqBLaBRahWahXR6KJ15mmh0OwLQoxK3YkhaFibGIW4k9MZbfCQhxHUyOS7xMiZ0OwPToxG3Ymh495AUZgRs6eEEGSTSBCzJMbij6T9scoLa29he4dgbp5gKLYLwiiSSTUFckQZvQKLRaVVX1T3b2AA/hkjwsMGCxgdsfiNOAJqFNaBRaFb7Ga1KJV7H3mlS/A6xkuRKXEJeLsrklgriFqfFwgKfFhlm2xOFAo0/54gHnAcST4/9RDrAo3AwcN3MgJEVIPIHGoDWTSOSieDrA5GDRZ2VlGTFYhJ6wF5uQeAKNQWvQHLQXwhkm++JJWVlZb7DouS5AEg00F+wMpaWlHb54s2vXrk+x0kbREyc5AzQpi2DFcXcA+X0vsciJQ5mcCAcYq5gtjjiPJl+ikF/2Z5Y3cRhLEukAP7T76QcGBliFJFqw+PXXvkSiTE6JYXaOrak69PX1qaNHjxpGSMimXS7ARrjThMO+RKOC9gZhJo6ERDNnzjQeWCd30JUrV9TixYvVnj171LvvvqvOnj3L2vYIg4OD2p+FlqApaAsaCxGBnJYMB/gLsdaWlhZjdQ6xWPyJ/7acrTQ1qQULFqj169cbhksRvvjiC+Nn4g02btyourq6Ivo3Aa3BEUZprU1snC8ZFBYW5uNhcAghknWBiooKtWbNGnXjxg01e/ZsozCWLl2q8vPzVW9vL9WRorS3txt/im7UvHnzVH19fVTfA61Bc9AeNOhLFkeOHPke5q/RvMT8+fONIQ/OdkL4vFI1tcGtL2joli1bZgx3MezFXDGSoVCo2ElxcfELvmSiLLJHm43r9u/fb0x+7969S4V4hBUrVqgpU6aojIwM9dZbb6m6upjuX9niSzYqhpBof38/FeGlWOXwsCH4W7duGXt33njjjVh7/h/4nIA8SIFluPNEAxVA7uPy5cshI39HO7Tmk1t8TkEe5vuIbIUT/tVJ69TN6Z+wxokWUyuuqhdLqswcAVp7zuckVFD2uIFrnarxN/nq6t+tY+tPIgbi/xtxgpfP1Kq6vgfmiOt9TkMeaqJY11Bnv2pZeFTV/mCl6sg+zZokMfF+Q6ua+Gml+p8rN1T7wBD+CosHE31OpOvDc6vrRPgt7xxRcARC7ADCf1McAI6w/Vbncp9TufFa7mP9p2/UsMpIPPi8s7d2UvmNx3xORp7z71lVJE5M9rkBpZFOHcvZPFZJItDBep9bkIed4J+shATnN7GPg7dNEmgAWoAmTOgWG+9zE/LAs0K9Cfb+pKenM6U6GQFagCaQ2jwMs3xuRB782OiXRB53pLHg0IeEGgpBG9BIUON4zOdW5OGfF+vBRQbwcCbOIlZAI6O00qOctuIbKfv27VsawqsJMR0SQTOyZXqRLxWQd8pjtZII2epLFeRlHhar1PF8nPQhqQnqVnMkgPDgw75UQl7ou2IdVmM/hkZTO+SpMReERr7jS0XkxV4WGwolfsSCOU/wxvgedR3GCaCNl3ypjAq6cxjdIifJ3pzkIsVJEOk+LyAvmo23DdzxynUB74E6D9w17Sfb5xXkZcdu3ry5GsmOKH5vOwE0AC1AEz4vIalQnpWXLtWdPDE6FD+QnODSpUtGftahoSFboj0RBDPKoAWfF5GXf1TsgtV4MV57h5Crxo4KdzPIzrZhwwZjPH7gwAEja58dY3zNOkNo/FGfl5ECeCKcE1hEDKIGGcqqqqrU9u3bVUNDg5Guw6tUV1er1atXG+XQ1tZm2/dqRPYg/m/4iOEET/oXPx6YJNkpfnT13d3dKjs7W8lVT0ZKjhgzk7kaOH5zc7Nau3atamxsNBKUtba22uoEYYIcqOsnqPz7neDxgBMExG/nuP/atWuqoKDA+E78GchT6XVQLsjQFyhvJDlGzla7CIS5RzkB6vhxKt7ECRAZ0L1zGJMtq0gSuvedO3caLR3G/byM4346OjqMAykoIwi2vLxcK4KjO9FFXfrvizhN8VsgrdFf5ebmNupOtjDOtHIAZJyWJKpq1apV6sKFC1R8CDAURLZmJLCtqamxDA6gzCNZvZeDUPWejfZE0ROME8u3qoC5c+daHaV7oCfYtm2b0e17PfoTDOZGhw4diqiBQNkj2qOxloO6/AqVHbkjhL2MD6eHcLwyGnAtE3mwB4gG1AES3ZrwJ7ExVHP0TvCqCjpgH4guEGcQJlqHg+yvUMH2OMG3xc5FujB2cMVn6kblLSo0SoqbBtS0kp5oFr4qxJ6ncu2fF2Tprg1A+Hlpe6niGHl2Z7vhCLoxf+EDsYeo2Dghq7fz1L2L0UyB+J3a+ufl5am0tDQ1Z84c42en9wJwAg3aUDdUaGJ6A2SiPhauJs7vv6z2LjriWFFhsSnUz07lp0WdatlF08AB6mIilZlYJ/iS2O/VvdQZI9y5fVdt/t3Hqrv5tuUCGiJJyWDq1KmOcQCdO51re4bUI9vaVPvdB/ZMoexnoy6oyOQ5wjNiO0aaojWn1MnNZ7QqPll5ijDsgfBh2JeUTFAG/lVaU2aW3TZsFCjzZ6hA5zjCz5ur2+o2/W6n0QuYgQuWEbVIJliMc8rwByu6Vheco/VHL1DSMohrHX9OxTlxgjy3aMLlY/V/xKKvWWVib4rVRju0jLr7kaIBE2DsS4o3eAerng5lofGuDYsv9Ge8UNQ1gUpzR8gUTXx7uD0sVsv3mB+kQipHvIPVXAdlgd4oTJm0+8tyHJXlPkf4uthisd5IWjsLQYws/kS7FcNO8Axmi4I67xKmV0SZZaAMqST3OwJOnWGm16kz3tVpNZHw18qRIKhYDv3j3+L3WAnX6jM6vRnKBGUj4ETMu4oHVlKPnJycp2XP+xpE9mIVjM7Y2mqSW7i7yrBYvkPHEXUcGmUiZbNWtox/k0pJ/R7hy9ioJXY42iGDTjKvRDhAIMlUDEM6rBj+EmVCZXjTGX4k9mFgQS2SSaPVQhvWGmJ1AJ2FKp1wKt5p1NkJvOtHYn9LBZCAI3xV7F9l3F5cWlraFqu4E+kAOp85depUs5yFxmThn/GurHFi5gxj/D3DH6AdseHgya3VOoLO2FzHAXTmGogEhXieYf+zY13kx6xVEotDIG3L62KrxS4EDSfCRoCsnETHAXS+B8/iH7bhzESW/1mZc4fEzSHGywHy1+TPNLENYkij0BfcKluFJ3UcAN8RYr2hz/87MXd5U57l1/LnI6wZ4oSe4idir0nC15y6ujr0GNvEToo1RuAA2MpxAvvm8B34Lnyn/7ufYkkTQgghhBBCCCGEEEIIIYRY8//7sBXUuKjNMQAAAABJRU5ErkJggg==";
var defaultLogo = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4goBCRAW1JPzYgAAAB1pVFh0Q29tbWVudAAAAAAAQ3JlYXRlZCB3aXRoIEdJTVBkLmUHAAACjklEQVR42u3Xv2teVRjA8ee5vlW7hPu+IY6J9wRUUhDBRUUcxH+g/kLEQV2rm4t/Q3EQF11EdHG06FIoCK2KThkKDn3JPUHEJQQSxaJtvMdNEBxcQkj4fLYLd/pyDs9zIgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgxGxtbf3re3NzU5QTkhIcr1JKjOMYwzC8kpl/HB4efrm/v//XMAzvZub5iHhkHMeXlToZnQTHaxzHKKV8Ok3T9Yj4fmVl5YVSytXMXLTWfouIG/91aUopD6t3/O6R4Pj1ff90Zj6ZmT9nZj9N01cRcW+t9f35fH6u7/tL8/n85mKxeHF1dfXWzs7OUd/3rx0cHPygnhXoTKxAEREbGxv3dV33YUTcnM1mHx0dHZ2LiG9ba891XfdjRDwbEU+01lZms9kHy+Xy9traWuzt7QlpBTqdWmsv/RO7667UWt/IzMVyufw9M3+ptV7ouu5yZpaIeH6apuuZubVcLm+XUi47/CbAqTUMw6sRsVtr/W4Yhrcz86eIWJum6YvMfC8iPsvMw9bahYj4OiIejYiPI+KhiLjYWrs1n8+/2d7eFtMEOLUeLKW8npmPjeN4JTNvdF13LSIeqLVea629WWv9JCKeysx3MvOZzLyamed3d3cdfk79G+CtYRgu/t//19fXTWUr0Jm8CI9HxKXW2v0RcTcz70TEndba3Yj4MyJ+jYidWuvnagEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcJb9DdihqgRC5qxJAAAAAElFTkSuQmCC";

onload = () => {

	var core = new Core(216, 216);
	core.preload(defaultTheme, colourTheme, defaultLogo);
	core.fps = 60;

	//ロード画面を隠す
	document.getElementById("enchant-stage").style.visibility = "hidden";

	//ロード完了後
	core.onload = () => {

		//再表示
		document.getElementById("enchant-stage").style.visibility = "visible";

		//ロード完了イベント
		ipcRenderer.send("core-loaded");

		var mainScene = core.rootScene;
		mainScene.backgroundColor = "rgba(255, 255, 255, 0)";

		var coreCentral = [108, 108];

		//拡張スプライト
		var SpriteEx = Class.create(Sprite, {
			initialize : function(width, height) {
				Sprite.call(this, width, height);
				this.originX = this.width / 2;
				this.originY = this.height / 2;
			},
			centerize : function() {
				this.x = coreCentral[0] - this.originX;
				this.y = coreCentral[1] - this.originY;
			}
		});

		//円のSurface
		function circleSurf(size, color) {
			var result = new Surface(size, size);
			result.context.beginPath();
			result.context.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2, true);
			result.context.fillStyle = color;
			result.context.fill();
			return result;
		}

		// 角丸の四角形を描画するためのユーティリティ関数(https://developer.mozilla.org/ja/docs/Web/Guide/HTML/Canvas_tutorial/Drawing_shapes)(一部改変)
		function roundedRect(ctx, x, y, width, height, radius, color) {
			ctx.beginPath();
			ctx.moveTo(x, y + radius);
			ctx.lineTo(x, y + height - radius);
			ctx.arcTo(x, y + height, x + radius, y + height, radius);
			ctx.lineTo(x + width - radius, y + height);
			ctx.arcTo(x + width, y + height, x + width, y + height - radius, radius);
			ctx.lineTo(x + width, y + radius);
			ctx.arcTo(x + width, y, x + width - radius, y, radius);
			ctx.lineTo(x + radius, y);
			ctx.arcTo(x, y, x, y + radius, radius);
			ctx.fillStyle = color;
			ctx.fill();
		}

		//background(文字盤)
		var bg = new Sprite(216, 216);
		var bgSurfaceS = new Surface(216, 216);
		bgSurfaceS.context.shadowColor = "rgba(0, 0, 0, 0.5)";
		bgSurfaceS.context.shadowBlur = 12;
		roundedRect(bgSurfaceS.context, 12, 12, 192, 192, 8, "white");
		bg.image = bgSurfaceS;
		var bgSurfaceC = new Surface(216, 216);
		bgSurfaceC.context.shadowColor = "rgba(0, 0, 0, 0.5)";
		bgSurfaceC.context.shadowBlur = 12;
		roundedRect(bgSurfaceC.context, 12, 12, 192, 192, 96, "white");
		mainScene.addChild(bg);
		ipcRenderer.on("form", (event, message) => {
			bg.image = (message == "square") ? bgSurfaceS : bgSurfaceC;
		});

		//背景テーマ
		var bgTheme = new SpriteEx(192, 192);
		with(bgTheme) {
			centerize();
			image = core.assets[defaultTheme];
		}
		mainScene.addChild(bgTheme);
		ipcRenderer.on("theme", (event, message) => {
			switch(message) {
				case "minimal" :
					bgTheme.visible = false;
					break;
				case "standard" :
					bgTheme.visible = true;
					bgTheme.image = core.assets[defaultTheme];
					break;
				case "colour" :
					bgTheme.visible = true;
					bgTheme.image = core.assets[colourTheme];
			}
		});

		//ロゴ
		var logo = new SpriteEx(192, 192);
		with(logo) {
			centerize();
			image = core.assets[defaultLogo];
		}
		mainScene.addChild(logo);
		ipcRenderer.on("logo", () => {
			if(logo.visible) {
				logo.visible = false;
			} else {
				logo.visible = true;
			}
		});

		//真ん中
		var center = new SpriteEx(6, 6);
		with(center) {
			centerize();
			image = circleSurf(6, "#222");
		}
		mainScene.addChild(center);

		//秒針
		var secHand = new SpriteEx(2, 72);
		with(secHand) {
			originX = 1;
			originY = coreCentral[1] - 28;
			centerize();
			backgroundColor = "#888";
			on("enterframe", () => {
				rotation = moment().seconds() * 6 + moment().milliseconds() / 1000 * 6;
			});
		}
		mainScene.addChild(secHand);

		//分針
		var minHand = new SpriteEx(3, 72);
		with(minHand) {
			originX = 1.5;
			originY = coreCentral[1] - 28;
			centerize();
			backgroundColor = "#444";
			on("enterframe", () => {
				if(core.frame == 1 || core.frame % 60 == 0) {
					rotation = moment().minutes() * 6 + moment().seconds() / 10;
				}
			});
		}
		mainScene.addChild(minHand);
		mainScene.insertBefore(minHand, secHand);

		//時針
		var hourHand = new SpriteEx(3, 48);
		with(hourHand) {
			originX = 1.5;
			originY = coreCentral[1] - 52;
			centerize();
			backgroundColor = "#444";
			on("enterframe", () => {
				if(core.frame == 1 || core.frame % 3600 == 0) {
					rotation = moment().hours() * 30 + moment().minutes() / 2;
				}
			});
		}
		mainScene.addChild(hourHand);
		mainScene.insertBefore(hourHand, secHand);
	};

	core.start();
};
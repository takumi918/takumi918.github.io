// electronモジュールを読み込み
const electron = require("electron");
const app = electron.app;
const BrowserWindow = electron.BrowserWindow;
const ipcMain = electron.ipcMain;
const Menu = electron.Menu;
const Tray = electron.Tray;
const nativeImage = electron.nativeImage;
const globalShortcut = electron.globalShortcut;

// npmのモジュール
const Store = require("electron-store");
const WindowState = require("electron-window-state");

var config = new Store({
	defaults : {
		form : "square",
		theme : "standard",
		"show-logo" : true,
		"always-on-top" : true
	}
});

var mainWindow;
app.on("ready",() => {

	// デフォルトの幅・高さ
	var state = WindowState({
		defaultWidth: 216,
		defaultHeight: 216
	});

	// BrowserWindowインスタンスを生成
	mainWindow = new BrowserWindow({
		x: state.x,
		y: state.y,
		width: state.width,
		height: state.height,
		transparent: true,
		frame: false,
		resizable: false,
		minimizable: false,
		alwaysOnTop: true,
		skipTaskbar: true,
		show: true
	});

	// ウィンドウ座標を保存
	state.manage(mainWindow);

	// コンフィグ設定を送信
	ipcMain.on("core-loaded", () => {
		with(mainWindow.webContents) {
			send("form", config.get("form"));
			send("theme", config.get("theme"));
			if(!config.get("show-logo")) {
				send("logo");
			}
		}
	});

	mainWindow.setAlwaysOnTop((config.get("always-on-top")) ? true : false);
	
	// index.htmlを表示
	mainWindow.loadURL("file://" + __dirname + "/assets/index.html");

	// ウィンドウを閉じたら参照を破棄
	mainWindow.on('closed', () => {
		mainWindow = null;
	});
});

// 全てのウィンドウを閉じたらアプリを終了
app.on('window-all-closed', function () {
	app.quit();
});

// タスクトレイに格納
var appIcon = null;
app.on('ready', () => {

	// タスクトレイにおけるアイコン
	appIcon = new Tray(nativeImage.createFromPath(__dirname + "/icon.png"));
	appIcon.on("click", () => {
		mainWindow.focus();
	});

	// タスクトレイアイコンのコンテキストメニュー
	var contextMenu = Menu.buildFromTemplate([
			{
				label: "設定", submenu: [
					{
						label: "文字盤の形状", submenu: [
							{
								label: "四角形", type: "radio", checked: (config.get("form") == "square") ? true : false, click: function() {
									mainWindow.webContents.send("form", "square");
									config.set("form", "square");
								}
							},
							{
								label: "円形", type: "radio", checked: (config.get("form") == "circle") ? true : false, click: function() {
									mainWindow.webContents.send("form", "circle");
									config.set("form", "circle");
								}
							}
						]
					},
					{
						label: "背景テーマ", submenu: [
							{
								label: "Minimal", type: "radio", checked: (config.get("theme") == "minimal") ? true : false, click: function() {
									mainWindow.webContents.send("theme", "minimal");
									config.set("theme", "minimal");
								}
							},
							{
								label: "Standard", type: "radio", checked: (config.get("theme") == "standard") ? true : false, click: function() {
									mainWindow.webContents.send("theme", "standard");
									config.set("theme", "standard");
								}
							},
							{
								label: "Colour", type: "radio", checked: (config.get("theme") == "colour") ? true : false, click: function() {
									mainWindow.webContents.send("theme", "colour");
									config.set("theme", "colour")
								}
							}
						]
					},
					{
						label: "ロゴの表示", type: "checkbox", checked: (config.get("show-logo")) ? true : false, click: function() {
							mainWindow.webContents.send("logo");
							config.set("show-logo", (config.get("show-logo")) ? false : true);
						}
					},
					{
						label: "常に手前", type: "checkbox", checked: (config.get("always-on-top")) ? true : false, click: function() {
							mainWindow.setAlwaysOnTop((mainWindow.isAlwaysOnTop()) ? false : true);
							config.set("always-on-top", (config.get("always-on-top")) ? false : true);
						}
					}
				]
			},
			{
				type: "separator"
			},
			{
				label: "終了", click: function () {
					mainWindow.close();
				}
			}
	]);

	appIcon.setToolTip("Timi");
	appIcon.setContextMenu(contextMenu);
});